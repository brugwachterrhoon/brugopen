import { BRIDGES } from "./bridges.mjs";

const SOURCE_URL = "https://opendata.ndw.nu/planningsfeed_brugopeningen.xml.gz";

function decodeXml(value = "") {
  return value
    .replaceAll("&amp;", "&")
    .replaceAll("&lt;", "<")
    .replaceAll("&gt;", ">")
    .replaceAll("&quot;", '"')
    .replaceAll("&apos;", "'")
    .trim();
}

function tagValue(xml, tag) {
  const escaped = tag.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const regex = new RegExp(
    `<(?:[\\w.-]+:)?${escaped}\\b[^>]*>([\\s\\S]*?)<\\/(?:[\\w.-]+:)?${escaped}>`,
    "i"
  );
  const match = regex.exec(xml);
  return match ? decodeXml(match[1].replace(/<[^>]+>/g, " ").replace(/\s+/g, " ")) : null;
}

function attributeValue(openingTag, attribute) {
  const escaped = attribute.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const match = new RegExp(`${escaped}\\s*=\\s*["']([^"']+)["']`, "i").exec(openingTag);
  return match ? decodeXml(match[1]) : null;
}

function chunks(xml, element) {
  const escaped = element.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const regex = new RegExp(
    `<(?:[\\w.-]+:)?${escaped}\\b[^>]*>[\\s\\S]*?<\\/(?:[\\w.-]+:)?${escaped}>`,
    "gi"
  );
  return xml.match(regex) ?? [];
}

function toIsoOrNull(value) {
  if (!value) return null;
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? null : date.toISOString();
}

function timestamp(value) {
  if (!value) return null;
  const ms = new Date(value).getTime();
  return Number.isNaN(ms) ? null : ms;
}

function containsBridge(situationXml, bridge) {
  // ISRS is de vaste objectcode uit de vaarwegdata. Namen kunnen wijzigen of
  // op meerdere bruggen lijken (zoals “Merwedebrug”), dus we matchen bewust
  // niet op vrije tekst.
  return situationXml.toLowerCase().includes(bridge.isrs.toLowerCase());
}

function parseRecord(recordXml, situationXml) {
  if (!/bridgeSwingInOperation/i.test(recordXml)) return null;

  const openingTag = recordXml.match(/<(?:[\w.-]+:)?situationRecord\b[^>]*>/i)?.[0] ?? "";
  const start = toIsoOrNull(tagValue(recordXml, "overallStartTime"));
  const end = toIsoOrNull(tagValue(recordXml, "overallEndTime"));
  const operatorActionStatus = tagValue(recordXml, "operatorActionStatus") ?? "unknown";
  const probability = tagValue(recordXml, "probabilityOfOccurrence") ?? "unknown";
  const ended = /<(?:[\w.-]+:)?(?:end|cancel)\b[^>]*>\s*true\s*<\//i.test(recordXml);

  return {
    id: attributeValue(openingTag, "id") ?? attributeValue(situationXml.match(/<(?:[\w.-]+:)?situation\b[^>]*>/i)?.[0] ?? "", "id"),
    start,
    end,
    operatorActionStatus,
    probability,
    ended,
    versionTime:
      toIsoOrNull(tagValue(recordXml, "situationRecordVersionTime")) ??
      toIsoOrNull(tagValue(situationXml, "situationVersionTime"))
  };
}

function durationMinutes(start, end) {
  const startMs = timestamp(start);
  const endMs = timestamp(end);
  if (startMs === null || endMs === null || endMs < startMs) return null;
  return Math.round((endMs - startMs) / 60_000);
}

function selectEvent(records, nowMs) {
  const usable = records.filter((record) => !record.ended && record.start);

  const active = usable
    .filter((record) => {
      const startMs = timestamp(record.start);
      const endMs = timestamp(record.end);
      const isImplementation = ["beingImplemented", "implemented"].includes(record.operatorActionStatus);
      return isImplementation && startMs !== null && startMs <= nowMs && (endMs === null || endMs > nowMs);
    })
    .sort((a, b) => timestamp(b.start) - timestamp(a.start))[0];

  if (active) {
    return {
      status: "open",
      statusLabel: "Brug open",
      message: "Wegverkeer is volgens de NDW-melding gestremd.",
      start: active.start,
      end: active.end,
      durationMinutes: durationMinutes(active.start, active.end),
      operatorActionStatus: active.operatorActionStatus,
      probability: active.probability,
      eventId: active.id,
      eventVersionTime: active.versionTime
    };
  }

  const upcoming = usable
    .filter((record) => {
      const startMs = timestamp(record.start);
      return startMs !== null && startMs > nowMs;
    })
    .sort((a, b) => timestamp(a.start) - timestamp(b.start))[0];

  if (upcoming) {
    const requested = upcoming.operatorActionStatus === "requested";
    return {
      status: requested ? "requested" : "expected",
      statusLabel: requested ? "Opening aangevraagd" : "Opening verwacht",
      message: requested
        ? "Deze opening is gemeld, maar nog niet als goedgekeurd aangeduid."
        : "Dit is de eerstvolgende opening in de actuele NDW-planningsfeed.",
      start: upcoming.start,
      end: upcoming.end,
      durationMinutes: durationMinutes(upcoming.start, upcoming.end),
      operatorActionStatus: upcoming.operatorActionStatus,
      probability: upcoming.probability,
      eventId: upcoming.id,
      eventVersionTime: upcoming.versionTime
    };
  }

  return {
    status: "none",
    statusLabel: "Geen opening gemeld",
    message: "De huidige NDW-snapshot bevat geen actieve of toekomstige opening voor deze brug.",
    start: null,
    end: null,
    durationMinutes: null,
    operatorActionStatus: null,
    probability: null,
    eventId: null,
    eventVersionTime: null
  };
}

export function parseNdwBridgeFeed(xml, { now = new Date() } = {}) {
  if (typeof xml !== "string" || !xml.includes("<")) {
    throw new TypeError("De NDW-feed is geen geldige XML-tekst.");
  }

  const nowMs = now.getTime();
  const publicationTime =
    toIsoOrNull(tagValue(xml, "publicationTime")) ??
    toIsoOrNull(tagValue(xml, "situationVersionTime"));
  const situations = chunks(xml, "situation");

  const bridges = BRIDGES.map((bridge) => {
    const matchingSituations = situations.filter((situation) => containsBridge(situation, bridge));
    const records = matchingSituations.flatMap((situation) =>
      chunks(situation, "situationRecord")
        .map((record) => parseRecord(record, situation))
        .filter(Boolean)
    );

    return {
      ...bridge,
      sourceUrl: SOURCE_URL,
      matchedSituations: matchingSituations.length,
      ...selectEvent(records, nowMs)
    };
  });

  return {
    source: "NDW Open Data · Planningsfeed Brugopeningen",
    sourceUrl: SOURCE_URL,
    publicationTime,
    processedAt: new Date().toISOString(),
    situationCount: situations.length,
    bridges
  };
}
