export const BRIDGES = [
  {
    id: "botlekbrug",
    name: "Botlekbrug",
    subtitle: "Nieuwe Botlekbrug · A15",
    isrs: "NLRTM001110888700281"
  },
  {
    id: "spijkenisserbrug",
    name: "Spijkenisserbrug",
    subtitle: "S102 · Oude Maas",
    isrs: "NLSPI001110572700266"
  },
  {
    id: "brug-over-de-noord",
    name: "Brug over de Noord",
    subtitle: "Alblasserdamsebrug · N915",
    isrs: "NLHIA001010577301210"
  },
  {
    id: "papendrechtsebrug",
    name: "Papendrechtsebrug",
    subtitle: "Merwedebrug Papendrecht · N3",
    isrs: "NLDOR001010577001143"
  },
  {
    id: "hartelbrug",
    name: "Hartelbrug",
    subtitle: "N218 · Hartelkanaal",
    isrs: "NLRTM0115B5487800010"
  },
  {
    id: "wantijbrug",
    name: "Wantijbrug",
    subtitle: "N3 · Dordrecht",
    isrs: "NLDOR001100553200025"
  }
];
