import http from "node:http";
import { readFile, writeFile, mkdir } from "node:fs/promises";
import { extname, join, normalize } from "node:path";
import { fileURLToPath } from "node:url";
import { gunzipSync } from "node:zlib";
import { parseNdwBridgeFeed } from "./src/parser.mjs";

const __dirname = fileURLToPath(new URL(".", import.meta.url));
const PUBLIC_DIR = join(__dirname, "public");
const CACHE_FILE = join(__dirname, "data", "cache.json");
const PORT = Number(process.env.PORT || 3000);
const FEED_URL = process.env.NDW_FEED_URL || "https://opendata.ndw.nu/planningsfeed_brugopeningen.xml.gz";
const REFRESH_INTERVAL_MS = Number(process.env.REFRESH_INTERVAL_MS || 300_000);
const REQUEST_TIMEOUT_MS = Number(process.env.REQUEST_TIMEOUT_MS || 20_000);
const REFRESH_SECRET = process.env.REFRESH_SECRET || "";

const MIME_TYPES = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml",
  ".ico": "image/x-icon"
};

let state = {
  data: null,
  lastSuccessAt: null,
  lastAttemptAt: null,
  error: null,
  refreshing: null
};

function json(res, statusCode, body) {
  res.writeHead(statusCode, {
    "content-type": "application/json; charset=utf-8",
    "cache-control": "no-store",
    "access-control-allow-origin": "*"
  });
  res.end(JSON.stringify(body));
}

async function loadCache() {
  try {
    const raw = await readFile(CACHE_FILE, "utf8");
    const cache = JSON.parse(raw);
    if (cache?.data) {
      state.data = cache.data;
      state.lastSuccessAt = cache.lastSuccessAt ?? cache.data.processedAt ?? null;
    }
  } catch {
    // Een ontbrekende of onleesbare cache is bij de eerste start normaal.
  }
}

async function saveCache() {
  try {
    await mkdir(join(__dirname, "data"), { recursive: true });
    await writeFile(
      CACHE_FILE,
      JSON.stringify({ data: state.data, lastSuccessAt: state.lastSuccessAt }, null, 2),
      "utf8"
    );
  } catch (error) {
    console.warn("Cache kon niet naar schijf worden geschreven:", error.message);
  }
}

function decodeFeed(buffer) {
  const bytes = new Uint8Array(buffer);
  const isGzip = bytes.length >= 2 && bytes[0] === 0x1f && bytes[1] === 0x8b;
  return isGzip ? gunzipSync(bytes).toString("utf8") : Buffer.from(bytes).toString("utf8");
}

async function downloadFeed() {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);

  try {
    const response = await fetch(FEED_URL, {
      signal: controller.signal,
      headers: {
        accept: "application/xml, application/gzip;q=0.9, */*;q=0.8",
        "user-agent": "BrugwachterDashboard/1.0 (+NDW Open Data consumer)"
      }
    });

    if (!response.ok) {
      throw new Error(`NDW antwoordde met HTTP ${response.status}`);
    }

    const buffer = await response.arrayBuffer();
    return decodeFeed(buffer);
  } finally {
    clearTimeout(timer);
  }
}

async function refreshData({ force = false } = {}) {
  const age = state.lastSuccessAt ? Date.now() - new Date(state.lastSuccessAt).getTime() : Infinity;
  if (!force && state.data && age < REFRESH_INTERVAL_MS) return state.data;
  if (state.refreshing) return state.refreshing;

  state.refreshing = (async () => {
    state.lastAttemptAt = new Date().toISOString();
    try {
      const xml = await downloadFeed();
      const parsed = parseNdwBridgeFeed(xml);
      state.data = parsed;
      state.lastSuccessAt = new Date().toISOString();
      state.error = null;
      await saveCache();
      console.log(`NDW-feed verwerkt: ${parsed.situationCount} situaties om ${state.lastSuccessAt}`);
      return parsed;
    } catch (error) {
      state.error = error instanceof Error ? error.message : String(error);
      console.error("Verversen NDW-feed mislukt:", state.error);
      if (!state.data) throw error;
      return state.data;
    } finally {
      state.refreshing = null;
    }
  })();

  return state.refreshing;
}

function dashboardPayload() {
  const staleMs = state.lastSuccessAt ? Date.now() - new Date(state.lastSuccessAt).getTime() : Infinity;
  return {
    ok: Boolean(state.data),
    stale: staleMs > REFRESH_INTERVAL_MS * 3,
    lastSuccessAt: state.lastSuccessAt,
    lastAttemptAt: state.lastAttemptAt,
    error: state.error,
    refreshIntervalSeconds: Math.round(REFRESH_INTERVAL_MS / 1000),
    data: state.data
  };
}

function requestHasRefreshAccess(req, url) {
  if (!REFRESH_SECRET) return false;
  const bearer = req.headers.authorization?.replace(/^Bearer\s+/i, "") ?? "";
  const headerSecret = req.headers["x-refresh-secret"] ?? "";
  const querySecret = url.searchParams.get("secret") ?? "";
  return [bearer, headerSecret, querySecret].includes(REFRESH_SECRET);
}

async function serveStatic(req, res, pathname) {
  const requested = pathname === "/" ? "/index.html" : pathname;
  const safePath = normalize(requested).replace(/^(\.\.[/\\])+/, "");
  const filePath = join(PUBLIC_DIR, safePath);

  if (!filePath.startsWith(PUBLIC_DIR)) {
    res.writeHead(403);
    res.end("Verboden");
    return;
  }

  try {
    const body = await readFile(filePath);
    const type = MIME_TYPES[extname(filePath).toLowerCase()] || "application/octet-stream";
    res.writeHead(200, {
      "content-type": type,
      "cache-control": type.startsWith("text/html") ? "no-cache" : "public, max-age=3600"
    });
    res.end(body);
  } catch {
    res.writeHead(404, { "content-type": "text/plain; charset=utf-8" });
    res.end("Niet gevonden");
  }
}

await loadCache();

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url || "/", `http://${req.headers.host || "localhost"}`);

  try {
    if (url.pathname === "/health") {
      json(res, 200, { status: "ok", lastSuccessAt: state.lastSuccessAt, error: state.error });
      return;
    }

    if (url.pathname === "/api/dashboard") {
      await refreshData();
      json(res, state.data ? 200 : 503, dashboardPayload());
      return;
    }

    if (url.pathname === "/api/refresh") {
      if (!requestHasRefreshAccess(req, url)) {
        json(res, 403, {
          ok: false,
          error: REFRESH_SECRET
            ? "Ongeldig refresh-geheim."
            : "Stel REFRESH_SECRET in om externe refresh-oproepen toe te staan."
        });
        return;
      }
      await refreshData({ force: true });
      json(res, state.data ? 200 : 503, dashboardPayload());
      return;
    }

    await serveStatic(req, res, decodeURIComponent(url.pathname));
  } catch (error) {
    json(res, 500, { ok: false, error: error instanceof Error ? error.message : String(error) });
  }
});

server.listen(PORT, "0.0.0.0", () => {
  console.log(`Brugwachter-dashboard draait op http://localhost:${PORT}`);
  refreshData({ force: true }).catch(() => {});
});

const interval = setInterval(() => {
  refreshData({ force: true }).catch(() => {});
}, REFRESH_INTERVAL_MS);
interval.unref();
