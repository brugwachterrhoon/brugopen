# Broncontrole bruggen

De website koppelt elke brug uitsluitend aan de vaste ISRS-code. De code is belangrijker dan de schrijfwijze van de naam.

| Kaart in dashboard | Officiële/gebruikte naam | ISRS-code |
|---|---|---|
| Botlekbrug | Nieuwe Botlekbrug | `NLRTM001110888700281` |
| Spijkenisserbrug | Spijkenisserbrug | `NLSPI001110572700266` |
| Brug over de Noord | Alblasserdamsebrug / Brug over de Noord | `NLHIA001010577301210` |
| Papendrechtsebrug | Merwedebrug Papendrecht | `NLDOR001010577001143` |
| Hartelbrug | Hartelbrug | `NLRTM0115B5487800010` |
| Wantijbrug | Wantijbrug | `NLDOR001100553200025` |

## Wat wel en niet is gecontroleerd

- De zes bruggen zijn als afzonderlijke objecten herkenbaar aan bovenstaande ISRS-codes.
- De NDW-planningsfeed is een gebeurtenissenfeed. Een brug staat alleen in een momentopname wanneer een relevante actieve of geplande melding aanwezig is.
- Daarom is het niet correct om te eisen dat alle zes codes op elk willekeurig moment tegelijk in het XML-bestand staan.
- De website toont bij afwezigheid: **Geen opening gemeld**. Dat betekent niet dat de brug de rest van de dag gegarandeerd niet opent.
- De parser matcht niet op losse namen. Dit voorkomt dat een andere brug met bijvoorbeeld “Merwedebrug” in de naam aan de verkeerde kaart wordt gekoppeld.
