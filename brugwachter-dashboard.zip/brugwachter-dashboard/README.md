# Brugwachter Live Dashboard

Een responsive Node.js-website met zes overzichtskaarten voor:

- Botlekbrug (Nieuwe Botlekbrug)
- Spijkenisserbrug
- Brug over de Noord / Alblasserdamsebrug
- Papendrechtsebrug / Merwedebrug Papendrecht
- Hartelbrug
- Wantijbrug

De server downloadt maximaal één keer per vijf minuten de officiële NDW Open Data-feed:

`https://opendata.ndw.nu/planningsfeed_brugopeningen.xml.gz`

Alle bezoekers gebruiken dezelfde servercache. Een bezoeker veroorzaakt dus niet zelfstandig een nieuwe aanvraag bij NDW.

## Wat wordt getoond?

- actieve brugopening;
- eerstvolgende geplande brugopening;
- verwachte begin- en eindtijd;
- geschatte duur op basis van de NDW-tijden;
- bron- en informatietijd;
- duidelijke melding wanneer de actuele feed geen opening bevat.

De koppeling gebeurt uitsluitend met vaste ISRS-codes. Daardoor is de site niet afhankelijk van wisselende schrijfwijzen van brugnamen en wordt een gelijknamige brug niet per ongeluk gekoppeld. Zie `BRONCONTROLE.md` voor de zes gecontroleerde codes.

## Installatie

1. Installeer Node.js 20 of nieuwer.
2. Kopieer eventueel `.env.example` naar uw hostinginstellingen.
3. Start de website:

```bash
npm start
```

4. Open `http://localhost:3000`.

Er zijn geen externe npm-pakketten nodig.

## Testen

```bash
npm test
```

## Vernieuwen

De server:

- ververst direct na het starten;
- ververst daarna iedere vijf minuten;
- ververst bij een dashboardverzoek wanneer de cache te oud is;
- bewaart de laatste succesvolle stand in `data/cache.json`;
- blijft de laatste succesvolle stand tonen als NDW tijdelijk niet bereikbaar is.

## Externe cronjob op gratis hosting

Gratis hosting kan in slaapstand gaan. Stel daarom `REFRESH_SECRET` in en laat een cronservice iedere vijf minuten deze URL aanroepen:

```text
https://jouwdomein.nl/api/refresh?secret=JOUW_GEHEIM
```

Een Authorization-header of `x-refresh-secret`-header is veiliger dan een queryparameter wanneer uw cronservice dat ondersteunt.

## Render

Een `render.yaml` is inbegrepen. Publiceer de map in een GitHub-repository en maak in Render een nieuwe Blueprint aan.

## Betekenis van de gegevens

“Opening verwacht” betekent dat een toekomstige opening in de NDW-planningsfeed staat. Het is geen garantie dat de brug exact op dat moment opent. Een lege melding betekent alleen dat de huidige snapshot geen actieve of toekomstige opening bevat; niet dat de brug de rest van de dag zeker dicht blijft voor de scheepvaart.

## Belangrijke technische beperking

De feed is geen volledige catalogus van alle bruggen, maar een actuele gebeurtenissenfeed. Een brug zonder actieve of geplande melding staat mogelijk niet in de huidige XML-snapshot. De kaart blijft dan wel zichtbaar en meldt dat er geen opening in de huidige feed staat.

Op hosts met een tijdelijk bestandssysteem blijft de cache tijdens de draaiende instantie beschikbaar, maar kan `data/cache.json` bij een herstart verdwijnen. De server haalt dan direct opnieuw de officiële feed op.
