import test from "node:test";
import assert from "node:assert/strict";
import { parseNdwBridgeFeed } from "../src/parser.mjs";

const fixture = `<?xml version="1.0" encoding="UTF-8"?>
<mc:messageContainer xmlns:mc="http://datex2.eu/schema/3/messageContainer" xmlns:com="http://datex2.eu/schema/3/common" xmlns:sit="http://datex2.eu/schema/3/situation">
  <mc:payload>
    <com:publicationTime>2026-08-02T17:20:00Z</com:publicationTime>
    <sit:situation id="NDW_NLRTM001110888700281_1">
      <sit:situationVersionTime>2026-08-02T17:19:00Z</sit:situationVersionTime>
      <sit:situationRecord id="event-botlek" version="1">
        <sit:probabilityOfOccurrence>probable</sit:probabilityOfOccurrence>
        <sit:validity><sit:validityTimeSpecification>
          <sit:overallStartTime>2026-08-02T18:30:00Z</sit:overallStartTime>
          <sit:overallEndTime>2026-08-02T18:42:00Z</sit:overallEndTime>
        </sit:validityTimeSpecification></sit:validity>
        <sit:operatorActionStatus>approved</sit:operatorActionStatus>
        <sit:generalNetworkManagementType>bridgeSwingInOperation</sit:generalNetworkManagementType>
      </sit:situationRecord>
    </sit:situation>
    <sit:situation id="NDW_NLDOR001100553200025_1">
      <sit:situationRecord id="event-wantij" version="1">
        <sit:probabilityOfOccurrence>certain</sit:probabilityOfOccurrence>
        <sit:validity><sit:validityTimeSpecification>
          <sit:overallStartTime>2026-08-02T17:15:00Z</sit:overallStartTime>
          <sit:overallEndTime>2026-08-02T17:27:00Z</sit:overallEndTime>
        </sit:validityTimeSpecification></sit:validity>
        <sit:operatorActionStatus>implemented</sit:operatorActionStatus>
        <sit:generalNetworkManagementType>bridgeSwingInOperation</sit:generalNetworkManagementType>
      </sit:situationRecord>
    </sit:situation>
  </mc:payload>
</mc:messageContainer>`;

test("herkent geplande en actieve brugopeningen op ISRS-code", () => {
  const result = parseNdwBridgeFeed(fixture, { now: new Date("2026-08-02T17:20:00Z") });
  const botlek = result.bridges.find((bridge) => bridge.id === "botlekbrug");
  const wantij = result.bridges.find((bridge) => bridge.id === "wantijbrug");
  const hartel = result.bridges.find((bridge) => bridge.id === "hartelbrug");

  assert.equal(botlek.status, "expected");
  assert.equal(botlek.durationMinutes, 12);
  assert.equal(wantij.status, "open");
  assert.equal(hartel.status, "none");
  assert.equal(result.situationCount, 2);
});

test("matcht niet alleen op een gelijkende brugnaam", () => {
  const misleadingFixture = `<?xml version="1.0"?>
  <messageContainer>
    <publicationTime>2026-08-02T17:20:00Z</publicationTime>
    <situation id="andere-merwedebrug">
      <situationRecord id="event-andere-merwedebrug">
        <overallStartTime>2026-08-02T18:30:00Z</overallStartTime>
        <overallEndTime>2026-08-02T18:40:00Z</overallEndTime>
        <operatorActionStatus>approved</operatorActionStatus>
        <generalNetworkManagementType>bridgeSwingInOperation</generalNetworkManagementType>
        <description>Opening van een andere Merwedebrug</description>
      </situationRecord>
    </situation>
  </messageContainer>`;

  const result = parseNdwBridgeFeed(misleadingFixture, { now: new Date("2026-08-02T17:20:00Z") });
  const papendrecht = result.bridges.find((bridge) => bridge.id === "papendrechtsebrug");
  assert.equal(papendrecht.status, "none");
  assert.equal(papendrecht.matchedSituations, 0);
});
