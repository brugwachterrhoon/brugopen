const cards = document.querySelector("#cards");
const cardTemplate = document.querySelector("#card-template");
const feedStatus = document.querySelector("#feed-status");
const feedTime = document.querySelector("#feed-time");
const notice = document.querySelector("#notice");

const dateFormatter = new Intl.DateTimeFormat("nl-NL", {
  timeZone: "Europe/Amsterdam",
  weekday: "short",
  day: "2-digit",
  month: "short",
  hour: "2-digit",
  minute: "2-digit"
});

const timeFormatter = new Intl.DateTimeFormat("nl-NL", {
  timeZone: "Europe/Amsterdam",
  hour: "2-digit",
  minute: "2-digit"
});

function formatDateTime(iso) {
  return iso ? dateFormatter.format(new Date(iso)).replace(" om ", " · ") : "—";
}

function relativeTime(iso) {
  if (!iso) return "tijdstip onbekend";
  const seconds = Math.round((new Date(iso).getTime() - Date.now()) / 1000);
  const abs = Math.abs(seconds);
  const rtf = new Intl.RelativeTimeFormat("nl-NL", { numeric: "auto" });
  if (abs < 90) return rtf.format(seconds, "second");
  if (abs < 5400) return rtf.format(Math.round(seconds / 60), "minute");
  if (abs < 129600) return rtf.format(Math.round(seconds / 3600), "hour");
  return rtf.format(Math.round(seconds / 86400), "day");
}

function openingPresentation(bridge) {
  if (bridge.status === "open") {
    const until = bridge.end ? `Tot ongeveer ${timeFormatter.format(new Date(bridge.end))}` : "Eindtijd niet gemeld";
    return { label: "Huidige status", time: "NU OPEN", detail: until };
  }
  if (bridge.start) {
    const duration = bridge.durationMinutes ? ` · circa ${bridge.durationMinutes} min` : "";
    return {
      label: "Volgende opening",
      time: formatDateTime(bridge.start),
      detail: `${relativeTime(bridge.start)}${duration}`
    };
  }
  return {
    label: "Volgende opening",
    time: "Niet gemeld",
    detail: "Geen toekomstige opening in de huidige feed"
  };
}

function renderCards(bridges) {
  cards.replaceChildren();
  bridges.forEach((bridge, index) => {
    const fragment = cardTemplate.content.cloneNode(true);
    const card = fragment.querySelector(".bridge-card");
    const presentation = openingPresentation(bridge);

    card.dataset.status = bridge.status;
    fragment.querySelector(".bridge-number").textContent = String(index + 1).padStart(2, "0");
    fragment.querySelector(".status-badge").textContent = bridge.statusLabel;
    fragment.querySelector("h2").textContent = bridge.name;
    fragment.querySelector(".subtitle").textContent = bridge.subtitle;
    fragment.querySelector(".opening-label").textContent = presentation.label;
    fragment.querySelector(".opening-time").textContent = presentation.time;
    fragment.querySelector(".opening-detail").textContent = presentation.detail;
    fragment.querySelector(".status-message").textContent = bridge.message;
    fragment.querySelector(".isrs").textContent = `ISRS ${bridge.isrs}`;
    const link = fragment.querySelector(".source-link");
    link.href = bridge.sourceUrl;
    cards.append(fragment);
  });
}

function showNotice(message) {
  notice.hidden = !message;
  notice.textContent = message || "";
}

async function loadDashboard() {
  try {
    const response = await fetch("/api/dashboard", { cache: "no-store" });
    const payload = await response.json();
    if (!response.ok || !payload.data) throw new Error(payload.error || "Geen dashboardgegevens ontvangen.");

    renderCards(payload.data.bridges);
    feedStatus.textContent = payload.stale ? "Laatst bekende gegevens" : "Live gegevens actief";
    const timestamp = payload.data.publicationTime || payload.lastSuccessAt;
    feedTime.textContent = timestamp ? `NDW bijgewerkt ${formatDateTime(timestamp)}` : "NDW-tijd onbekend";

    if (payload.error) {
      showNotice(`Nieuwe gegevens konden niet worden opgehaald. Getoond wordt de laatste succesvolle stand. ${payload.error}`);
    } else if (payload.stale) {
      showNotice("De brongegevens zijn ouder dan verwacht. Controleer bij twijfel ook de officiële vaarweginformatie.");
    } else {
      showNotice("");
    }
  } catch (error) {
    feedStatus.textContent = "Gegevens niet beschikbaar";
    feedTime.textContent = "Probeer het later opnieuw";
    showNotice(error instanceof Error ? error.message : String(error));
  }
}

await loadDashboard();
setInterval(loadDashboard, 60_000);
